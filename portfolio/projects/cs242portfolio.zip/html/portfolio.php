<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Portfolio</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- JQuery -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>

    <!-- Custom CSS -->
    <style>
    body {
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    </style>
</head>

<body>

    <!-- include php files -->
    <?php include 'nav.php' ?>
    <?php require 'parser.php' ?>

    <?php
    $id = htmlspecialchars($_GET['id']);
    $parser = new XMLParser();
    ?>

    <!-- Page Content -->
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
            	<h1>Files: <?php echo htmlspecialchars($id); ?></h1>
                <?php if(!($parser->isFile($id))): ?>
                    <table class="table table-hover">
                        <tr>
                            <th>Title</th>
                            <th>Date</th>
                            <th>Version</th>
                            <th>Most Recent Commit</th>
                        </tr>
                        <?php $parser->listFiles($id); ?>
                    </table>
                    <?php else: ?>
                        <?php $parser->listFileInfo($id); ?>
                    <?php endif; ?>

                <?php include "sql/displaycomments.php";
                $display = new DisplayComments($id);
                $display->print_comments();
                ?>


                <!-- comment field -->
                <div class="mycomment well">
                    <form class="form" action="sql/submitcomment.php" method="post">
                        <legend>Add a comment</legend>
                        <input type="hidden" name="path" value="<?php echo $id; ?>">
                        <input type="hidden" name="parent" value="-1">
                        <div class="form-group"><input type="text" class="form-control" name="name" required placeholder="name"></div>
                        <div class="form-group"><textarea name="comment" placeholder="comment(1000 characters)" class="form-control" rows="3" maxlength="1000" required></textarea></div>
                        <input type="submit" class="btn btn-primary" value="submit">
                    </form>
                </div>

            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->

</body>

</html>

