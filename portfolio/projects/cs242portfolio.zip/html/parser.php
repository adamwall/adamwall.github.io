<?php
include_once ('file.php');
include_once ('dir.php');
class XMLParser {
	public $files = array();
	public $dirs = array();
	public $logs = array();

	function __construct(){
		$mylists = simplexml_load_file('xml/svn_list.xml');
		$mylogs = simplexml_load_file('xml/svn_log.xml');
		$entries = $mylists->list[0]->entry;
		foreach($entries as $entry){
			$logs = $this->findLogs($entry->name, $mylogs);
			switch((string) $entry['kind']){
				case 'dir':
				$dir = new Dir($entry, $logs);
				array_push($this->dirs, $dir);
				break;
				case 'file':
				$file = new File($entry, $logs);
				array_push($this->files, $file);
				break;
			}
		}
	}

	function findLogs($filename, $logs){
		$log_stack = array();
		foreach($logs->logentry as $log){
			foreach($log->paths[0] as $path){
				if(substr($path,9) == $filename){
					array_push($log_stack, $log);
				}
			}  
		}
		return $log_stack;
	}

	function isFile($id){
		foreach($this->files as $file){
			if($id == $file->name){
				return true;
			}
		}
		return false;
	}

    function isDir($id){
        foreach($this->dirs as $dir){
            if($id == $dir->name){
                return true;
            }
        }
        return false;
    }

	function findFile($filename) {
		foreach($this->files as $file){
			if($file->name == $filename)
				return $file;
		}
	}

	function listFileInfo($id){
		$file = $this->findFile($id);
		if($file){
			echo 'Size: ' , $file->size, 'B <br>';
			echo 'Type: ' , $file->type , '<br>';
			echo 'Path: ' , $file->name , '<br>';
			echo '<a href="https://subversion.ews.illinois.edu/svn/sp15-cs242/agwall2/', $file->name ,'" target="iframe1">Open File</a><br>';
			echo '<table class="table table-striped">
			<tr>
			<th>number</th>
			<th>author</th>
			<th>info</th>
			<th>date</th>
			</tr>';
			foreach($file->logs as $entry_log){
				echo '<tr>
				<td>', $entry_log['revision'] ,'</td>
				<td>', $entry_log->author ,'</td>
				<td>', $entry_log->msg ,'</td>
				<td>', $entry_log->date ,'</td>';
			}

			echo '</table>';


			echo '<br><iframe name="iframe1" width="800" height="600"></iframe>';
		}
	}

	function listFiles($id){
		foreach($this->files as $file){
			if(substr($file->name,0,strlen($id)) == $id){
				$entry_name = substr($file->name,strlen($id));
				if(substr($entry_name,0,1)=='/') $entry_name = substr($entry_name,1);
				if((strpos($entry_name,'/') == FALSE) && ($id!=$file->name)){
					echo '<tr><td><a href="?id=',$file->name,'" style="display:block; text-decoration: none">&nbsp' , $entry_name ,' (file)</a></td>
					<td><a href="?id=',$file->name,'" style="display:block; text-decoration: none">&nbsp' , $file->logs[0]->date ,'</a></td>
					<td><a href="?id=',$file->name,'" style="display:block; text-decoration: none">&nbsp' , $file->commit['revision'] ,' </a></td>
					<td><a href="?id=',$file->name,'" style="display:block; text-decoration: none">&nbsp' , $file->logs[0]->msg ,'</a></td>
					</tr>';
				}
			}
		}

		foreach($this->dirs as $dir){
			if(substr($dir->name,0,strlen($id)) == $id){
				$entry_name = substr($dir->name,strlen($id));
				if(substr($entry_name,0,1)=='/') $entry_name = substr($entry_name,1);
				if((strpos($entry_name,'/') == FALSE) && ($id!=$dir->name)){
					echo '<tr><td><a href="?id=',$dir->name,'" style="display:block; text-decoration: none">&nbsp' , $entry_name ,' (dir)</a></td>
					<td><a href="?id=',$dir->name,'" style="display:block; text-decoration: none">&nbsp' , $dir->logs[0]->date ,'</a></td>
					<td><a href="?id=',$dir->name,'" style="display:block; text-decoration: none">&nbsp' , $dir->commit['revision'] ,' </a></td>
					<td><a href="?id=',$dir->name,'" style="display:block; text-decoration: none">&nbsp' , $dir->logs[0]->msg ,'</a></td>
					</tr>';
				}
			}
		}
	}
}
?>