<?php
class DisplayComments {

    public $parents = array();
    public $children = array();
    private $path;

    function __construct($path){
        $this->path = $path;
        if(!isset($path)){
            $this->path = "";
        }
        include_once "sql_conn.php";
        $stmt = $conn->prepare("SELECT id, parent, name, comment, date FROM comments WHERE path=? ORDER BY id ASC");
        $stmt->bind_param("s", $this->path);

        $stmt->execute();
        $result = $stmt->get_result();

        while($row = $result->fetch_assoc()) {
            if($row['parent'] === -1){//root comment
                $this->parents[$row['id']] = $row;
            }
            else{//child comment
                $this->children[$row['parent']][] = $row;
            }
        }
        $conn->close();
        $stmt->close();
    }

    private function format_comment($comment, $depth){
        echo '<h4 class="media-heading">' . $comment['name'] . '<a href="comment.php?id=' . $this->path . '&parent=' . $comment['id'] . '"> (Reply)</a>' . '</h4>';
        echo '<small>posted on ' . $comment['date'] . '</small>';
        echo '<p>' . $comment['comment'] . '</p>';
    }

    private function print_parent($comment, $depth = 0)
    {

        foreach ($comment as $c)
        {
            if($depth ==0){ //if it's a parent use <li> tag
                echo '<li class="media">';
                echo '<a class="pull-left">
                   <img class="media-object" src="img/default_user.gif" height="64" width="64">
                   </a>';
                echo '<div class="media-body">';
                $this->format_comment($c, $depth);
                if (isset($this->children[$c['id']]))
                {
                    $this->print_parent($this->children[$c['id']], $depth + 1);
                }
                echo '</div>';
                echo '</li>';
            }
            else {
                echo '<div class="media">';
                echo '<a class="pull-left">
                   <img class="media-object" src="img/default_user.gif" height="64" width="64">
                   </a>';
                echo '<div class="media-body">';
                $this->format_comment($c, $depth);
                if (isset($this->children[$c['id']])) {
                    $this->print_parent($this->children[$c['id']], $depth + 1);
                }
                echo '</div>';
                echo '</div>';
            }
        }

    }

    public function print_comments()
    {
        if(count($this->parents) > 0) {
            echo '<ul class="media-list well">';
            echo '<legend>Comments for ' . htmlspecialchars($this->path) . '</legend>';
            $this->print_parent($this->parents);
            echo '</ul>';
        }
    }
}