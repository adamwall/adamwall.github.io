<?php

include_once "sql_conn.php";

$stmt = $conn->prepare("SELECT id, parent, name, comment, date FROM comments WHERE path=? ORDER BY id ASC");
$stmt->bind_param("s", $id);

$stmt->execute();
$result = $stmt->get_result();

$threads = array();
while($row = $result->fetch_assoc()) {
    if($row['parent'] === -1){//root comment
        $threads[$row['id']] = array('comment' => $row, 'replies' => array());
    }
    else{//child comment
        $threads[$row['parent']]['replies'][] = $row;
    }
}
$stmt->close();
$conn->close();

//echo '<pre>';print_r($threads);exit;