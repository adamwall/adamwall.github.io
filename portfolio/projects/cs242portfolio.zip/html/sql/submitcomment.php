<?php

include_once "sql_conn.php";

$stmt = $conn->prepare("INSERT INTO comments (parent, path, name, comment) VALUES (?,?,?,?)");
$stmt->bind_param("isss" , $parent, $path, $name, $comment);

$bad_words = file('swearWords.txt', FILE_IGNORE_NEW_LINES);

$parent = $_POST["parent"];
$path = $_POST["path"];
$name = str_ireplace($bad_words, '****', $_POST["name"]);
$comment = str_ireplace($bad_words, '****', $_POST["comment"]);;
$stmt->execute();

echo '<h1>comment created</h1>';
$back_direct = htmlspecialchars($_SERVER['HTTP_REFERER']);
echo '<a href="' . $back_direct . '">click to go back</a>';

//close connection
$stmt->close();
$conn->close();
?>