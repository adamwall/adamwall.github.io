<?php
class Dir{
	public $name;
	public $commit;
	public $author;
	public $date;
	public $logs;

	function __construct($entry, $logs){
		$this->name = $entry->name;
		$this->commit = $entry->commit;
		$this->author = $entry->author;
		$this->date = $entry->date;
		$this->logs = $logs;
	}
}
?>