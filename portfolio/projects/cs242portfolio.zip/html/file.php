<?php
class File{
	public $name;
	public $commit;
	public $author;
	public $date;
	public $size;
	public $type;
	public $logs;

	function __construct($entry, $logs){
		$this->name = $entry->name;
		$this->commit = $entry->commit;
		$this->author = $entry->author;
		$this->date = $entry->date;
		$this->size = $entry->size;
		$this->type = $this->getFileType($entry->name);
		$this->logs = $logs;
	}

	function getFileType($path){
		if(strpos( strtolower($path) , 'test' ) != FALSE){
			return 'test';
		}
		switch(substr(strrchr($path,'.'),1)){
			case 'java':
			case 'rb':
			return 'code';
			break;
			case 'docx':
			case 'pdf':
			return 'documentation';
			break;
			case 'png':
			return 'image';
			break;
			case 'json':
			case 'xml':
			return 'resource';
			break;
		}
		return 'misc';
	}
}
?>