import java.awt.event.*;

import javax.swing.JApplet;
import javax.swing.JButton;

import ChessLibrary.*;

/**
 * 
 * @file ChessController.java
 * @author agwall2
 * @date Feb 28, 2015
 * 
 */
public class ChessController extends JApplet {

    private Game game = new Game();
    private Board board;
    private ChessView view;
    public int colorsTurn = Piece.WHITE;
    public int whiteScore = 0;
    public int blackScore = 0;

    public void init() {
	view = new ChessView(this);
	initializeNewBoard();

	// add listeners
	view.addUndoListener(new UndoListener());
	view.addResignListener(new ResignListener(this));
	view.addRestartListener(new RestartListener(this));
	view.addCustomListener(new CustomListener(this));
	for (int row = 0; row < 8; row++) {
	    for (int col = 0; col < 8; col++) {
		view.addTileListener(row, col, new TileListener(this, row, col));
	    }
	}
    }

    public void restartGame() {
	whiteScore = 0;
	blackScore = 0;
	view.updateScores(this);
	initializeNewBoard();
    }

    public void initializeNewBoard() {
	colorsTurn = Piece.WHITE;
	view.whitesTurn.setVisible(true);
	view.blacksTurn.setVisible(false);
	view.underCheck.setVisible(false);
	board = new Board();
	board.placePieces();
	view.updateBoardPositions(board);
    }

    public void initializeCustomBoard() {
	colorsTurn = Piece.WHITE;
	view.whitesTurn.setVisible(true);
	view.blacksTurn.setVisible(false);
	view.underCheck.setVisible(false);
	board = new Board();
	board.placeCustomPieces();
	view.updateBoardPositions(board);
    }

    // control listeners
    public boolean firstClick = true;
    public int firstClickRow;
    public int firstClickCol;

    class TileListener implements ActionListener {
	public int row;
	public int col;
	public JButton source;
	public ChessController controller;

	public TileListener(ChessController controller, int row, int col) {
	    this.controller = controller;
	    this.row = row;
	    this.col = col;
	}

	/**
	 * If a piece is under check, it will display that text in the view
	 */
	public void updateCheckView() {
	    if (game.isInCheck(board, Piece.BLACK, board.blackKingRowPos,
		    board.blackKingColPos)) {
		view.underCheck.setText("Black under check");
		view.underCheck.setVisible(true);
	    } else if (game.isInCheck(board, Piece.WHITE,
		    board.whiteKingRowPos, board.whiteKingColPos)) {
		view.underCheck.setText("White under check");
		view.underCheck.setVisible(true);
	    } else
		view.underCheck.setVisible(false);
	}

	public void updateMateView() {
	    if (game.isInCheckMate(board, Piece.BLACK)) {
		whiteScore++;
		view.updateScores(controller);
		view.showCheckmateDialog(controller,
			"White wins! Would you like to play another game?");
	    } else if (game.isInCheckMate(board, Piece.WHITE)) {
		blackScore++;
		view.updateScores(controller);
		view.showCheckmateDialog(controller,
			"Black wins! Would you like to play another game?");
	    }
	}

	public void actionPerformed(ActionEvent e) {
	    JButton source = (JButton) e.getSource();
	    if (firstClick) {
		if (source.getIcon() == null)
		    return; // make sure it is not an empty tile
		if (board.getPiece(row, col).color != colorsTurn)
		    return; // if it's not that colors turn, then dont move
		firstClickRow = row;
		firstClickCol = col;
		view.chessTiles[row][col].setBorderPainted(true); // highlight
								  // the tile
		firstClick = false;
	    } else {
		if (row == firstClickRow && col == firstClickCol) {
		    // if we select the same tile, we are changing pieces
		    view.chessTiles[firstClickRow][firstClickCol]
			    .setBorderPainted(false);
		    firstClick = true;
		}
		int valid = board.getPiece(firstClickRow, firstClickCol).move(
			board, row, col);
		if (valid == 0) {
		    // update board view
		    updateCheckView();

		    view.chessTiles[firstClickRow][firstClickCol]
			    .setBorderPainted(false);
		    view.updateBoardPositions(board);
		    firstClick = true;
		    // switch turns
		    if (colorsTurn == Piece.WHITE) {
			view.whitesTurn.setVisible(false);
			view.blacksTurn.setVisible(true);
			colorsTurn = Piece.BLACK;
		    } else {
			view.whitesTurn.setVisible(true);
			view.blacksTurn.setVisible(false);
			colorsTurn = Piece.WHITE;
		    }
		    updateMateView();
		}
	    }
	}
    }

    class UndoListener implements ActionListener {
	/**
	 * undoes the move and changes the turn back to the player
	 */
	public void actionPerformed(ActionEvent e) {
	    board.undo();
	    view.updateBoardPositions(board);
	    if (colorsTurn == Piece.WHITE) {
		view.whitesTurn.setVisible(true);
		view.blacksTurn.setVisible(false);
		colorsTurn = Piece.BLACK;
	    } else {
		view.whitesTurn.setVisible(true);
		view.blacksTurn.setVisible(false);
		colorsTurn = Piece.WHITE;
	    }
	}
    }

    class ResignListener implements ActionListener {
	ChessController controller;

	public ResignListener(ChessController controller) {
	    this.controller = controller;
	}

	public void actionPerformed(ActionEvent e) {
	    view.showResignDialog(controller);
	}
    }

    class RestartListener implements ActionListener {
	ChessController controller;

	public RestartListener(ChessController controller) {
	    this.controller = controller;
	}

	public void actionPerformed(ActionEvent e) {
	    view.showRestartDialoag(controller);
	}
    }

    class CustomListener implements ActionListener {
	ChessController controller;

	public CustomListener(ChessController controller) {
	    this.controller = controller;
	}

	public void actionPerformed(ActionEvent e) {
	    view.showCustomDialog(controller);
	}
    }
}