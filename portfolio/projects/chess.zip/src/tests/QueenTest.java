package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import ChessLibrary.*;

/**
 * 
 * @file QueenTest.java
 * @author agwall2
 * @date Feb 12, 2015
 * 
 */
public class QueenTest {

    Board b;
    Pawn pawn;
    Pawn pawn2;
    Queen queen1;
    Queen queen2;

    @Before
    public void setUp() throws Exception {
	b = new Board();
	pawn = new Pawn(Piece.BLACK, 1, 5);
	pawn2 = new Pawn(Piece.BLACK, 3, 6);
	queen1 = new Queen(Piece.WHITE, 6, 3);
	queen2 = new Queen(Piece.WHITE, 1, 0);
	b.placePiece(pawn);
	b.placePiece(pawn2);
	b.placePiece(queen1);
	b.placePiece(queen2);
    }

    @Test
    public void validMoveTest() {
	// empty space
	assertTrue(queen2.validMove(b, 5, 0));
	assertTrue(queen2.validMove(b, 0, 0));
	assertTrue(queen2.validMove(b, 1, 3));
	assertTrue(queen2.validMove(b, 1, 1));
	// enemy at end of path
	assertTrue(queen2.validMove(b, 1, 5));
	// piece blocking path
	assertTrue(!queen2.validMove(b, 1, 6));
	assertTrue(queen2.validMove(b, 2, 1));
	// invalidmove
	assertTrue(!queen2.validMove(b, 2, 3));

	// empty space
	assertTrue(queen1.validMove(b, 5, 4));
	assertTrue(queen1.validMove(b, 5, 2));
	assertTrue(queen1.validMove(b, 7, 2));
	assertTrue(queen1.validMove(b, 7, 4));
	// enemy at end of path
	assertTrue(queen1.validMove(b, 3, 6));
	// piece blocking path
	assertTrue(!queen1.validMove(b, 2, 7));
	// invalid move
	assertTrue(!queen1.validMove(b, 2, 1));
    }

}
