package tests;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Before;

import ChessLibrary.*;

/**
 * 
 * @file PieceTests.java
 * @author agwall2
 * @date Feb 12, 2015
 * 
 */
public class PieceTests {

    Board b;
    Piece p1;
    Piece p2;
    Piece p3;

    @Before
    public void setUp() {
	b = new Board();
	p1 = new Piece(Piece.WHITE, 0, 0);
	p2 = new Piece(Piece.BLACK, 1, 1);
	p3 = new Piece(Piece.WHITE, 2, 2);
	b.placePiece(p1);
	b.placePiece(p2);
	b.placePiece(p3);
    }

    @Test
    public void emptyOrEnemyTest() {
	assertTrue(p1.emptyOrEnemy(b, 1, 1));
	assertTrue(p1.emptyOrEnemy(b, 3, 2));
	assertTrue(!p1.emptyOrEnemy(b, 2, 2));
    }

    public void posToStringTest() {
	Piece p4 = new Piece(Piece.WHITE, 7, 7);

	assertEquals(p1.positionToString(), "a8");
	assertEquals(p2.positionToString(), "b7");
	assertEquals(p3.positionToString(), "c6");
	assertEquals(p4.positionToString(), "h1");
    }

}
