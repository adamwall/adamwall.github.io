package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import ChessLibrary.Board;
import ChessLibrary.Pawn;
import ChessLibrary.Piece;
import ChessLibrary.Bishop;

/**
 * 
 * @file BishopTests.java
 * @author agwall2
 * @date Feb 12, 2015
 * 
 */
public class BishopTests {

    Board b;
    Piece bishop;
    Piece pawn;

    @Before
    public void setUp() throws Exception {
	b = new Board();
	pawn = new Pawn(Piece.BLACK, 3, 6);
	b.placePiece(pawn);
	bishop = new Bishop(Piece.WHITE, 6, 3);
	b.placePiece(bishop);
    }

    @Test
    public void validMoveTest() {
	// empty space
	assertTrue(bishop.validMove(b, 5, 4));
	assertTrue(bishop.validMove(b, 5, 2));
	assertTrue(bishop.validMove(b, 7, 2));
	assertTrue(bishop.validMove(b, 7, 4));
	// enemy at end of path
	assertTrue(bishop.validMove(b, 3, 6));
	// piece blocking path
	assertTrue(!bishop.validMove(b, 2, 7));
	// invalid move
	assertTrue(!bishop.validMove(b, 2, 1));
    }

}
