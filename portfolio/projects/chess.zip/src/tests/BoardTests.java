package tests;

import ChessLibrary.*;
import static org.junit.Assert.*;

import org.junit.Test;

public class BoardTests {

    @Test
    public void testArrayListPieces() {
	Board b = new Board();
	b.placePieces();
	assertEquals(16, b.blackPieces.size());
	assertEquals(16, b.whitePieces.size());
    }

    @Test
    public void testPiecesOnTiles() {
	Board b = new Board();
	b.placePieces();

	// test empty spaces at start of a chess game
	for (int i = 2; i < b.rows - 2; i++) {
	    for (int j = 0; j < b.columns; j++) {
		assertTrue(!b.tiles[i][j].hasPiece);
		assertTrue(b.tiles[i][j].pieceOnTile == null);
	    }
	}

	// test if pawns on are the tiles of the board
	for (int i = 0; i < 8; i++) {
	    assertTrue(b.tiles[1][i].hasPiece);
	    assertTrue(b.tiles[b.rows - 2][i].hasPiece);
	    assertTrue(b.tiles[1][i].pieceOnTile instanceof Pawn);
	    assertTrue(b.tiles[b.rows - 2][i].pieceOnTile instanceof Pawn);
	}
    }

}
