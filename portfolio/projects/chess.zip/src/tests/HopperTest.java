package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import ChessLibrary.*;

/**
 * 
 * @file HopperTest.java
 * @author agwall2
 * @date Feb 19, 2015
 * 
 */
public class HopperTest {

    Board b;

    @Before
    public void setUp() throws Exception {
	b = new Board();
    }

    /**
     * tests basic moves of hopper
     */
    @Test
    public void test() {
	Piece whtHopper = new Hopper(Piece.WHITE, 3, 4);
	b.placePiece(whtHopper);
	Piece whtPawn = new Pawn(Piece.WHITE, 4, 3);
	b.placePiece(whtPawn);
	Piece blkPawn = new Pawn(Piece.BLACK, 2, 5);
	b.placePiece(blkPawn);
	Piece blkQueen = new Queen(Piece.BLACK, 5, 2);
	b.placePiece(blkQueen);

	assertTrue(whtHopper.validMove(b, 1, 6));
	assertTrue(whtHopper.validMove(b, 5, 2));
	assertFalse(whtHopper.validMove(b, 2, 3));
    }

}
