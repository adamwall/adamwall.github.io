package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import ChessLibrary.*;

public class LastMoveTest {

    @Test
    public void testUndo() {
	Board b = new Board();
	Piece p1 = new Queen(Piece.WHITE, 4, 4);
	Piece p2 = new Queen(Piece.BLACK, 6, 4);
	b.placePiece(p1);
	b.placePiece(p2);
	p1.move(b, 5, 4);
	b.undo();
	assertEquals(p1.rowPos, 4);
	assertEquals(p1.colPos, 4);

	p1.move(b, 6, 4);
	b.undo();
	assertEquals(p1.rowPos, 4);
	assertEquals(p1.colPos, 4);
	assertEquals(p2.rowPos, 6);
	assertEquals(p2.colPos, 4);
    }

}
