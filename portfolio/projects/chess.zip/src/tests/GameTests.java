package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import ChessLibrary.*;

/**
 * 
 * @file GameTests.java
 * @author agwall2
 * @date Feb 12, 2015
 * 
 */
public class GameTests {

    Board b;
    Game g;

    @Before
    public void setUp() throws Exception {
	b = new Board();
	g = new Game();
    }

    @Test
    public void checkTest1() {
	// attack enemy causes king to be put in check
	Piece wP = new Pawn(Piece.WHITE, 5, 3);
	b.tiles[5][3].placePiece(wP);
	b.whitePieces.add(wP);
	Piece wK = new King(Piece.WHITE, 7, 3);
	b.tiles[7][3].placePiece(wK);
	b.whitePieces.add(wK);
	b.whiteKingRowPos = 7;
	b.whiteKingColPos = 3;
	Piece bQ = new Queen(Piece.BLACK, 0, 3);
	b.tiles[0][3].placePiece(bQ);
	b.blackPieces.add(bQ);
	bQ.move(b, 5, 3);
	assertTrue(g.isInCheck(b, Piece.WHITE, 7, 3));

    }

    @Test
    public void checkTest2() {
	// move piece blocking own king causes check
	Piece wR = new Rook(Piece.WHITE, 5, 3);
	b.tiles[5][3].placePiece(wR);
	b.whitePieces.add(wR);
	Piece wK = new King(Piece.WHITE, 7, 3);
	b.tiles[7][3].placePiece(wK);
	b.whitePieces.add(wK);
	b.whiteKingRowPos = 7;
	b.whiteKingColPos = 3;
	Piece bQ = new Queen(Piece.BLACK, 0, 3);
	b.tiles[0][3].placePiece(bQ);
	b.blackPieces.add(bQ);
	assertEquals(-1, wR.move(b, 5, 7));
    }

    @Test
    public void checkTest3() {
	// take piece out of check
	Piece wP = new Pawn(Piece.WHITE, 5, 3);
	b.tiles[5][3].placePiece(wP);
	b.whitePieces.add(wP);
	Piece wK = new King(Piece.WHITE, 7, 3);
	b.tiles[7][3].placePiece(wK);
	b.whitePieces.add(wK);
	b.whiteKingRowPos = 7;
	b.whiteKingColPos = 3;
	Piece bQ = new Queen(Piece.BLACK, 0, 3);
	b.tiles[0][3].placePiece(bQ);
	b.blackPieces.add(bQ);
	bQ.move(b, 5, 3);
	assertTrue(g.isInCheck(b, Piece.WHITE, 7, 3));
	wK.move(b, 7, 4);
	assertTrue(!g.isInCheck(b, Piece.WHITE, 7, 4));
    }

    @Test
    public void testCheck4() {
	// taking piece causing check puts king out of check
	Piece wP = new Pawn(Piece.WHITE, 5, 3);
	b.tiles[5][3].placePiece(wP);
	b.whitePieces.add(wP);

	Piece wK = new King(Piece.WHITE, 7, 3);
	b.tiles[7][3].placePiece(wK);
	b.whitePieces.add(wK);
	b.whiteKingRowPos = 7;
	b.whiteKingColPos = 3;

	Piece bQ = new Queen(Piece.BLACK, 0, 3);
	b.tiles[0][3].placePiece(bQ);
	b.blackPieces.add(bQ);

	Piece wR = new Rook(Piece.WHITE, 5, 5);
	b.tiles[5][5].placePiece(wR);
	b.whitePieces.add(wR);

	bQ.move(b, 5, 3);
	assertTrue(g.isInCheck(b, Piece.WHITE, 7, 3));
	wR.move(b, 5, 3);
	assertTrue(!g.isInCheck(b, Piece.WHITE, 7, 3));
    }

    @Test
    public void checkmateTest1() {
	// simple checkmate test, king is cornered by a queen and bishop

	Piece wK = new King(Piece.WHITE, 7, 0);
	b.tiles[7][0].placePiece(wK);
	b.whitePieces.add(wK);
	b.whiteKingRowPos = 7;
	b.whiteKingColPos = 0;

	Piece bQ = new Queen(Piece.BLACK, 5, 0);
	b.tiles[5][0].placePiece(bQ);
	b.blackPieces.add(bQ);

	Piece bB = new Bishop(Piece.BLACK, 6, 2);
	b.tiles[6][2].placePiece(bB);
	b.blackPieces.add(bB);

	assertTrue(g.isInCheckMate(b, Piece.WHITE));
    }

    @Test
    public void checkmateTest2() {
	// able to block out of check(ischeckmate=false
	Piece wK = new King(Piece.WHITE, 7, 0);
	b.tiles[7][0].placePiece(wK);
	b.whitePieces.add(wK);
	b.whiteKingRowPos = 7;
	b.whiteKingColPos = 0;

	Piece bQ = new Queen(Piece.BLACK, 5, 0);
	b.tiles[5][0].placePiece(bQ);
	b.blackPieces.add(bQ);

	Piece wR = new Rook(Piece.WHITE, 5, 5);
	b.tiles[4][5].placePiece(wR);
	b.whitePieces.add(wR);

	assertTrue(!g.isInCheckMate(b, Piece.WHITE));
    }

    /**
     * http://en.wikipedia.org/wiki/Scholar%27s_mate
     */
    public void scholarsMate() {
	b.placePieces();
	assertEquals(0, b.getPiece(6, 4).move(b, 4, 4));// white pawn
	assertEquals(0, b.getPiece(1, 4).move(b, 3, 4));// black pawn
	assertEquals(0, b.getPiece(7, 3).move(b, 3, 7));// white queen
	assertEquals(0, b.getPiece(0, 1).move(b, 2, 2));// black knight1
	assertEquals(0, b.getPiece(7, 5).move(b, 4, 2));// white bishop
	assertEquals(0, b.getPiece(0, 6).move(b, 2, 5));// black knight2
	assertEquals(0, b.getPiece(3, 7).move(b, 1, 5));// white queen into
							// black checkmate

	assertEquals(15, b.blackPieces.size());
	assertEquals(16, b.whitePieces.size());
	assertFalse(g.isInCheckMate(b, Piece.WHITE));
	assertTrue(g.isInCheckMate(b, Piece.BLACK));
    }

}
