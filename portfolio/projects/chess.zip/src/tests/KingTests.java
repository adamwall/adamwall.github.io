package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import ChessLibrary.*;

/**
 * 
 * @file KingTests.java
 * @author agwall2
 * @date Feb 12, 2015
 * 
 */
public class KingTests {

    Board b;
    Piece king;
    Piece pawn;
    Piece pawn2;

    @Before
    public void setUp() throws Exception {
	b = new Board();
	king = new King(Piece.WHITE, 6, 3);
	b.placePiece(king);
    }

    @Test
    public void moveTest() {
	pawn2 = new Pawn(Piece.BLACK, 5, 3);
	pawn = new Pawn(Piece.BLACK, 4, 4);
	b.placePiece(pawn);
	b.placePiece(pawn2);
	// cannot take pawn because it would leave him in check(invalid move)
	assertEquals(-1, king.move(b, 5, 3));
	// insuring that the piece was not removed from bag
	assertEquals(2, b.blackPieces.size());
	// valid move
	assertEquals(0, king.move(b, 7, 3));
	assertEquals(7, b.whiteKingRowPos);
    }

    @Test
    public void validMoveTest() {
	Piece whitePawn = new Pawn(Piece.WHITE, 6, 4);
	b.placePiece(whitePawn);
	Piece blckPawn = new Pawn(Piece.BLACK, 6, 2);
	b.placePiece(blckPawn);
	// empty
	assertTrue(king.validMove(b, 5, 4));
	// ally
	assertTrue(!king.validMove(b, 6, 4));
	// enemy
	assertTrue(king.validMove(b, 6, 2));
    }

}
