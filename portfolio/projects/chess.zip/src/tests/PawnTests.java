package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import ChessLibrary.*;

/**
 * 
 * @file PawnTests.java
 * @author agwall2
 * @date Feb 12, 2015
 * 
 */
public class PawnTests {

    Board b;
    Piece pawn;
    Piece pawn2;

    @Before
    public void setUp() throws Exception {
	b = new Board();
	pawn = new Pawn(Piece.BLACK, 1, 5);
	pawn2 = new Pawn(Piece.WHITE, 6, 5);
	b.placePiece(pawn);
	b.placePiece(pawn2);
    }

    @Test
    public void validMoveTest() {
	Piece dummy = new Piece(Piece.WHITE, 2, 6);
	Piece dummy2 = new Piece(Piece.WHITE, 2, 5);
	b.placePiece(dummy);
	b.placePiece(dummy2);
	// diagonal
	assertEquals(true, pawn.validMove(b, 2, 6));
	assertEquals(false, pawn.validMove(b, 2, 4));
	// down (cannot take)
	assertTrue(!pawn.validMove(b, 2, 5));
	// down2 (cannot move)
	assertTrue(!pawn.validMove(b, 3, 5));

	// up
	assertTrue(pawn2.validMove(b, 5, 5));
	// up2
	assertTrue(pawn2.validMove(b, 4, 5));

	assertEquals(3, b.whitePieces.size());
	assertEquals(1, b.blackPieces.size());
	// test if pawn can take pieces
	pawn.move(b, 2, 6);
	assertEquals(2, b.whitePieces.size());
    }

}
