package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import ChessLibrary.*;

/**
 * 
 * @file RookTests.java
 * @author agwall2
 * @date Feb 12, 2015
 * 
 */
public class RookTests {

    Board b;
    Piece rook;
    Piece pawn;

    @Before
    public void setUp() throws Exception {
	b = new Board();
	pawn = new Pawn(Piece.BLACK, 1, 5);
	rook = new Rook(Piece.WHITE, 1, 0);
	b.placePiece(pawn);
	b.placePiece(rook);
    }

    @Test
    public void validMoveTest() {
	// empty space
	assertTrue(rook.validMove(b, 5, 0));
	assertTrue(rook.validMove(b, 0, 0));
	assertTrue(rook.validMove(b, 1, 3));
	assertTrue(rook.validMove(b, 1, 1));
	// enemy at end of path
	assertTrue(rook.validMove(b, 1, 5));
	// piece blocking path
	assertTrue(!rook.validMove(b, 1, 6));
	// invalid move
	assertTrue(!rook.validMove(b, 2, 1));
    }

}
