package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import ChessLibrary.*;

/**
 * 
 * @file KnightTest.java
 * @author agwall2
 * @date Feb 12, 2015
 * 
 */
public class KnightTest {

    Board b;
    Knight kn;
    Pawn p;

    @Before
    public void setUp() throws Exception {
	b = new Board();
	kn = new Knight(Piece.WHITE, 3, 3);
	p = new Pawn(Piece.BLACK, 5, 4);
	b.placePiece(kn);
	b.placePiece(p);
    }

    @Test
    /**
     * test basic moves of knight
     */
    public void validMoveTest() {
	// valid moves
	assertTrue(kn.validMove(b, 4, 5));
	assertTrue(kn.validMove(b, 1, 2));
	assertTrue(kn.validMove(b, 5, 4));
    }

}
