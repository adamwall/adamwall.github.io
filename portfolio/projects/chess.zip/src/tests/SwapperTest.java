package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import ChessLibrary.*;

/**
 * 
 * @file SwapperTest.java
 * @author agwall2
 * @date Feb 19, 2015
 * 
 */
public class SwapperTest {

    Board b;
    Game g;

    @Before
    public void setUp() throws Exception {
	b = new Board();
	g = new Game();
    }

    /**
     * Tests a simple swap with an ally piece
     */
    @Test
    public void testSimpleSwap() {
	Piece swapper = new Swapper(Piece.WHITE, 5, 6);
	b.placePiece(swapper);
	Piece ally = new Pawn(Piece.WHITE, 2, 3);
	b.placePiece(ally);

	assertFalse(swapper.validMove(b, 5, 5)); // nothing to swap with
	assertFalse(swapper.validMove(b, 5, 6)); // can't swap with self
	assertTrue(swapper.validMove(b, 2, 3));

	assertEquals(0, swapper.move(b, 2, 3));
	assertEquals(ally.rowPos, 5);
	assertEquals(ally.colPos, 6);
	assertEquals(swapper.rowPos, 2);
	assertEquals(swapper.colPos, 3);
	assertTrue(b.getPiece(2, 3) instanceof Swapper);
    }

    /**
     * tests a swap that would place the king in check, therefor invalid move
     */
    @Test
    public void testCheckSwap() {
	Piece blkRook = new Rook(Piece.BLACK, 0, 3);
	b.placePiece(blkRook);

	Piece whtSwap = new Swapper(Piece.WHITE, 6, 3);
	b.placePiece(whtSwap);
	Piece whtKing = new King(Piece.WHITE, 7, 0);
	b.placePiece(whtKing);

	assertTrue(whtSwap.validMove(b, 7, 0));
	assertEquals(-1, whtSwap.move(b, 7, 0));

	// make sure no positions changed
	assertEquals(7, b.whiteKingRowPos);
	assertEquals(0, b.whiteKingColPos);
	assertEquals(7, whtKing.rowPos);
	assertEquals(0, whtKing.colPos);
	assertEquals(6, whtSwap.rowPos);
	assertEquals(3, whtSwap.colPos);
	assertTrue(b.getPiece(7, 0) instanceof King);
	assertTrue(b.getPiece(6, 3) instanceof Swapper);
    }

    /**
     * tests a swap that would place king out of check
     */
    @Test
    public void testSwapOutOfCheck() {
	Piece wK = new King(Piece.WHITE, 7, 0);
	b.placePiece(wK);

	Piece bQ = new Queen(Piece.BLACK, 5, 0);
	b.placePiece(bQ);

	Piece bB = new Bishop(Piece.BLACK, 6, 2);
	b.placePiece(bB);

	assertTrue(g.isInCheckMate(b, Piece.WHITE));

	Piece wSwap = new Swapper(Piece.WHITE, 0, 7);
	b.placePiece(wSwap);
	assertFalse(g.isInCheckMate(b, Piece.WHITE));
    }
}
