import java.awt.Color;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

import ChessLibrary.*;

class ChessView {
    public JButton[][] chessTiles = new JButton[8][8];
    public static final Color LIGHT = new Color(255, 206, 158);
    public static final Color DARK = new Color(209, 139, 71);
    private JButton undoButton;
    private JButton resignButton;
    private JButton restartButton;
    private JButton customButton;
    public JLabel whitesTurn = new JLabel(
	    "<html><font color=gray>White's Turn</font></html>");
    public JLabel blacksTurn = new JLabel(
	    "<html><font color=black>Black's Turn</font></html>");
    public JLabel whiteScore;
    public JLabel blackScore;
    public JLabel underCheck;
    // images
    private ImageIcon white_pawn = new ImageIcon("white_pawn.png");
    private ImageIcon black_pawn = new ImageIcon("black_pawn.png");
    private ImageIcon white_rook = new ImageIcon("white_rook.png");
    private ImageIcon black_rook = new ImageIcon("black_rook.png");
    private ImageIcon white_knight = new ImageIcon("white_knight.png");
    private ImageIcon black_knight = new ImageIcon("black_knight.png");
    private ImageIcon white_bishop = new ImageIcon("white_bishop.png");
    private ImageIcon black_bishop = new ImageIcon("black_bishop.png");
    private ImageIcon white_queen = new ImageIcon("white_queen.png");
    private ImageIcon black_queen = new ImageIcon("black_queen.png");
    private ImageIcon white_king = new ImageIcon("white_king.png");
    private ImageIcon black_king = new ImageIcon("black_king.png");
    private ImageIcon white_hopper = new ImageIcon("white_hopper.png");
    private ImageIcon black_hopper = new ImageIcon("black_hopper.png");
    private ImageIcon white_swapper = new ImageIcon("white_swapper.png");
    private ImageIcon black_swapper = new ImageIcon("black_swapper.png");

    public ChessView(ChessController itsApplet) {
	itsApplet.getContentPane().setLayout(null);
	createLabels(itsApplet);
	createTiles(itsApplet);
	drawButtons(itsApplet);
    }

    public void drawButtons(ChessController itsApplet) {
	undoButton = new JButton("Undo");
	undoButton.setBounds(0, 450, 70, 25);
	itsApplet.getContentPane().add(undoButton);
	resignButton = new JButton("Resign");
	resignButton.setBounds(90, 450, 80, 25);
	itsApplet.getContentPane().add(resignButton);
	restartButton = new JButton("Restart");
	restartButton.setBounds(190, 450, 80, 25);
	itsApplet.getContentPane().add(restartButton);
	customButton = new JButton("Custom Pieces");
	customButton.setBounds(290, 450, 120, 25);
	itsApplet.getContentPane().add(customButton);
    }

    public void createLabels(ChessController itsApplet) {
	// letttering
	for (int row = 0; row < 8; row++) {
	    JLabel lblNumbers = new JLabel("" + (8 - row));
	    lblNumbers.setBounds(420, 20 + (50 * row), 40, 10);
	    itsApplet.getContentPane().add(lblNumbers);

	    JLabel lblLetters = new JLabel("" + (char) ('A' + row));
	    lblLetters.setBounds(20 + (50 * row), 420, 40, 10);
	    itsApplet.getContentPane().add(lblLetters);
	}
	whiteScore = new JLabel("<html><font color=gray>Player 1(White): "
		+ itsApplet.whiteScore + "</font></html>");
	whiteScore.setBounds(500, 20, 100, 15);
	itsApplet.getContentPane().add(whiteScore);
	blackScore = new JLabel("<html><font color=black>Player 2(Black): "
		+ itsApplet.blackScore + "</font></html>");
	blackScore.setBounds(620, 20, 100, 15);
	itsApplet.getContentPane().add(blackScore);

	whitesTurn.setBounds(560, 50, 100, 15);
	blacksTurn.setBounds(560, 50, 100, 15);
	blacksTurn.setVisible(false);
	itsApplet.getContentPane().add(whitesTurn);
	itsApplet.getContentPane().add(blacksTurn);

	underCheck = new JLabel("");
	underCheck.setBounds(540, 100, 150, 15);
	underCheck.setVisible(false);
	itsApplet.getContentPane().add(underCheck);
    }

    public void createTiles(ChessController itsApplet) {
	for (int row = 0; row < 8; row++) {
	    for (int col = 0; col < 8; col++) {
		JButton btn = new JButton("");
		if ((row + col) % 2 == 0)
		    btn.setBackground(LIGHT);
		else
		    btn.setBackground(DARK);
		Border thickBorder = new LineBorder(Color.WHITE, 5);
		btn.setBorder(thickBorder);
		btn.setBorderPainted(false);
		btn.setBounds(col * 50, row * 50, 50, 50);
		itsApplet.getContentPane().add(btn);
		chessTiles[row][col] = btn;

	    }
	}
    }

    public void addCustomListener(ActionListener a) {
	customButton.addActionListener(a);
    }

    public void addTileListener(int row, int col, ActionListener a) {
	chessTiles[row][col].addActionListener(a);
    }

    public void addUndoListener(ActionListener a) {
	undoButton.addActionListener(a);
    }

    public void addResignListener(ActionListener a) {
	resignButton.addActionListener(a);
    }

    public void addRestartListener(ActionListener a) {
	restartButton.addActionListener(a);
    }

    public void updateScores(ChessController controller) {
	whiteScore.setText("<html><font color=gray>Player 1(White): "
		+ controller.whiteScore + "</font></html>");
	blackScore.setText("<html><font color=black>Player 2(Black): "
		+ controller.blackScore + "</font></html>");
    }

    public void showCheckmateDialog(ChessController controller, String display) {
	int restart = JOptionPane.showConfirmDialog(controller, display,
		"Restart", JOptionPane.YES_NO_OPTION);
	if (restart == JOptionPane.YES_OPTION) {
	    controller.initializeNewBoard();
	}
    }

    public void showRestartDialoag(ChessController controller) {
	int firstRestart = JOptionPane.showConfirmDialog(controller,
		"Player 1, would you like to restart?", "Restart",
		JOptionPane.YES_NO_OPTION);
	if (firstRestart == JOptionPane.YES_OPTION) {
	    int secondRestart = JOptionPane.showConfirmDialog(controller,
		    "Player 2, would you like to restart?", "Restart",
		    JOptionPane.YES_NO_OPTION);
	    if (secondRestart == JOptionPane.YES_OPTION) {
		controller.restartGame();
	    }
	}
    }

    public void showCustomDialog(ChessController controller) {
	int custom = JOptionPane.showConfirmDialog(controller,
		"Would you like to use custom pieces?", "Custom Pieces",
		JOptionPane.YES_NO_OPTION);
	if (custom == JOptionPane.YES_OPTION) {
	    controller.initializeCustomBoard();
	}
    }

    public void showResignDialog(ChessController controller) {
	int resign = JOptionPane.showConfirmDialog(controller,
		"Are you sure you would like to resign?", "Resign",
		JOptionPane.YES_NO_OPTION);
	if (resign == JOptionPane.YES_OPTION) {
	    if (controller.colorsTurn == Piece.WHITE)
		controller.blackScore++;
	    else
		controller.whiteScore++;
	    updateScores(controller);
	    controller.initializeNewBoard();
	}
    }

    public void updateBoardPositions(Board board) {
	for (int row = 0; row < 8; row++) {
	    for (int col = 0; col < 8; col++) {
		Piece p = board.getPiece(row, col);
		if (p == null)
		    chessTiles[row][col].setIcon(null);
		if (p instanceof Pawn) {
		    if (p.color == Piece.WHITE)
			chessTiles[row][col].setIcon(white_pawn);
		    else
			chessTiles[row][col].setIcon(black_pawn);
		}
		if (p instanceof Rook) {
		    if (p.color == Piece.WHITE)
			chessTiles[row][col].setIcon(white_rook);
		    else
			chessTiles[row][col].setIcon(black_rook);
		}
		if (p instanceof Knight) {
		    if (p.color == Piece.WHITE)
			chessTiles[row][col].setIcon(white_knight);
		    else
			chessTiles[row][col].setIcon(black_knight);
		}
		if (p instanceof Bishop) {
		    if (p.color == Piece.WHITE)
			chessTiles[row][col].setIcon(white_bishop);
		    else
			chessTiles[row][col].setIcon(black_bishop);
		}
		if (p instanceof Queen) {
		    if (p.color == Piece.WHITE)
			chessTiles[row][col].setIcon(white_queen);
		    else
			chessTiles[row][col].setIcon(black_queen);
		}
		if (p instanceof King) {
		    if (p.color == Piece.WHITE)
			chessTiles[row][col].setIcon(white_king);
		    else
			chessTiles[row][col].setIcon(black_king);
		}
		if (p instanceof Hopper) {
		    if (p.color == Piece.WHITE)
			chessTiles[row][col].setIcon(white_hopper);
		    else
			chessTiles[row][col].setIcon(black_hopper);
		}
		if (p instanceof Swapper) {
		    if (p.color == Piece.WHITE)
			chessTiles[row][col].setIcon(white_swapper);
		    else
			chessTiles[row][col].setIcon(black_swapper);
		}
	    }
	}
    }
}