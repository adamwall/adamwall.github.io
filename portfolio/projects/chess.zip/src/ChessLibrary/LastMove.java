package ChessLibrary;

public class LastMove {
    // class used as bookkeeping of the last move made.
    // Piece A moves to tile containing Piece B

    public Piece pieceA; // the piece that was on the source tile
    public boolean hasPieceA; // if the source tile had a piece
    public int rowA; // the source row position
    public int colA; // the source col position
    public Piece pieceB; // the piece that was on the destination tile
    public boolean hasPieceB; // if the destination tile had a piece
    public int rowB; // the destination row position
    public int colB; // the destination col position

    public LastMove(Piece pA, boolean hPA, int rA, int cA, Piece pB,
	    boolean hPB, int rB, int cB) {
	this.pieceA = pA;
	this.hasPieceA = hPA;
	this.rowA = rA;
	this.colA = cA;
	this.pieceB = pB;
	this.hasPieceB = hPB;
	this.rowB = rB;
	this.colB = cB;
    }

    /**
     * undoes the last move
     * 
     * @param board
     */
    public void undo(Board board) {
	Tile tileA = board.tiles[rowA][colA];
	Tile tileB = board.tiles[rowB][colB];
	// revert piece positions
	if (hasPieceA) {
	    pieceA.rowPos = rowA;
	    pieceA.colPos = colA;
	}
	if (hasPieceB) {
	    pieceB.rowPos = rowB;
	    pieceB.colPos = colB;
	}
	if (pieceA instanceof King) {
	    board.updateKingPos(pieceA.color, rowA, colA);
	}
	if (pieceB instanceof King) {
	    board.updateKingPos(pieceB.color, rowB, colB);
	}
	// revert tile positions
	tileA.pieceOnTile = pieceA;
	tileA.hasPiece = hasPieceA;
	tileB.pieceOnTile = pieceB;
	tileB.hasPiece = hasPieceB;
	if (!(pieceA instanceof Swapper)) {
	    // add the piece back to the bag
	    if (hasPieceB) {
		if (pieceB.color == Piece.BLACK)
		    board.blackPieces.add(pieceB);
		else
		    board.whitePieces.add(pieceB);
	    }
	}
    }
}
