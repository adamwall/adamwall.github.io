package ChessLibrary;

import java.util.ArrayList;

/**
 * 
 * Board for the Chess games.
 * 
 * @file Board.java
 * @author agwall2
 * @date 2/9/2015
 *
 */
public class Board {

    public int rows;
    public int columns;
    public Tile[][] tiles;// array of the tiles of the chessboard, where
			  // tiles[0][0] corresponds to the upper-left corner
			  // of the board, A8
    public ArrayList<Piece> blackPieces;
    public ArrayList<Piece> whitePieces;
    public LastMove lastmove = null;

    // positions on board for both kings. used for check and checkmate
    public int whiteKingRowPos;
    public int whiteKingColPos;
    public int blackKingRowPos;
    public int blackKingColPos;

    /**
     * default constructor for an ordinary chess board
     */
    public Board() {
	rows = 8;
	columns = 8;
	tiles = new Tile[rows][columns];
	blackPieces = new ArrayList<Piece>();
	whitePieces = new ArrayList<Piece>();
	blackKingRowPos = -10;
	blackKingColPos = -10;
	whiteKingColPos = -10;
	whiteKingRowPos = -10;
	setUpBoard();
    }

    /**
     * sets up the board for an ordinary game of chess
     */
    public void setUpBoard() {
	colorBoard();
    }

    public void colorBoard() {
	for (int row = 0; row < rows; row++) {
	    for (int col = 0; col < columns; col++) {
		// nearest neighbors of a tile are the opposite color
		if ((row + col) % 2 == 0)
		    tiles[row][col] = new Tile(Tile.LIGHT);
		else
		    tiles[row][col] = new Tile(Tile.DARK);
	    }
	}
    }

    /**
     * places all the pieces on the chess board
     */
    public void placePieces() {
	placePawns();
	placeRooks();
	placeKnights();
	placeBishops();
	placeQueens();
	placeKings();
    }

    public void placeCustomPieces() {
	placePawns();
	placeRooks();
	placeHoppers();
	placeSwappers();
	placeQueens();
	placeKings();
    }

    public void placePawns() {
	for (int row = 1; row <= rows - 2; row += rows - 3) {
	    // row 1 and row 6 pawns
	    for (int col = 0; col < columns; col++) {
		if (row == 1) {
		    // black pawns
		    Piece pawn = new Pawn(Piece.BLACK, row, col);
		    placePiece(pawn);
		} else if (row == rows - 2) {
		    // white pawns
		    Piece pawn = new Pawn(Piece.WHITE, row, col);
		    placePiece(pawn);
		}
	    }
	}
    }

    public void placeRooks() {
	// four corners of the chess board

	// upperLeft
	Piece uLRook = new Rook(Piece.BLACK, 0, 0);
	placePiece(uLRook);
	// upperRight
	Piece uRRook = new Rook(Piece.BLACK, 0, columns - 1);
	placePiece(uRRook);
	// bottomLeft
	Piece bLRook = new Rook(Piece.WHITE, rows - 1, 0);
	placePiece(bLRook);
	// bottomRight
	Piece bRRook = new Rook(Piece.WHITE, rows - 1, columns - 1);
	placePiece(bRRook);
    }

    public void placeKnights() {
	Piece uLKnight = new Knight(Piece.BLACK, 0, 1);
	placePiece(uLKnight);

	Piece uRKnight = new Knight(Piece.BLACK, 0, columns - 2);
	placePiece(uRKnight);

	Piece bLKnight = new Knight(Piece.WHITE, rows - 1, 1);
	placePiece(bLKnight);

	Piece bRKnight = new Knight(Piece.WHITE, rows - 1, columns - 2);
	placePiece(bRKnight);
    }

    public void placeBishops() {
	Piece uLBishop = new Bishop(Piece.BLACK, 0, 2);
	placePiece(uLBishop);

	Piece uRBishop = new Bishop(Piece.BLACK, 0, columns - 3);
	placePiece(uRBishop);

	Piece bLBishop = new Bishop(Piece.WHITE, rows - 1, 2);
	placePiece(bLBishop);

	Piece bRBishop = new Bishop(Piece.WHITE, rows - 1, columns - 3);
	placePiece(bRBishop);
    }

    public void placeQueens() {
	Piece blackQueen = new Queen(Piece.BLACK, 0, 3);
	placePiece(blackQueen);

	Piece whiteQueen = new Queen(Piece.WHITE, rows - 1, 3);
	placePiece(whiteQueen);
    }

    public void placeKings() {
	Piece blackKing = new King(Piece.BLACK, 0, 4);
	placePiece(blackKing);

	Piece whiteKing = new King(Piece.WHITE, rows - 1, 4);
	placePiece(whiteKing);
    }

    public void placeSwappers() {
	Piece uLSwap = new Swapper(Piece.BLACK, 0, 1);
	placePiece(uLSwap);

	Piece uRSwap = new Swapper(Piece.BLACK, 0, columns - 2);
	placePiece(uRSwap);

	Piece bLSwap = new Swapper(Piece.WHITE, rows - 1, 1);
	placePiece(bLSwap);

	Piece bRSwap = new Swapper(Piece.WHITE, rows - 1, columns - 2);
	placePiece(bRSwap);
    }

    public void placeHoppers() {
	Piece uLHopper = new Hopper(Piece.BLACK, 0, 2);
	placePiece(uLHopper);

	Piece uRHopper = new Hopper(Piece.BLACK, 0, columns - 3);
	placePiece(uRHopper);

	Piece bLHopper = new Hopper(Piece.WHITE, rows - 1, 2);
	placePiece(bLHopper);

	Piece bRHopper = new Hopper(Piece.WHITE, rows - 1, columns - 3);
	placePiece(bRHopper);
    }

    public Piece getPiece(int row, int col) {
	return tiles[row][col].pieceOnTile;
    }

    /**
     * moves a piece on the chess board
     * 
     * @param currRow
     *            current row pos of the piece
     * @param currCol
     *            current col pos of the piece
     * @param destRow
     *            destination row pos the piece wants to go to
     * @param destCol
     *            destination col pos the piece wants to go to
     */
    public void movePiece(int currRow, int currCol, int destRow, int destCol) {
	Piece temp = getPiece(currRow, currCol);
	if (temp == null)
	    return;
	Tile currTile = tiles[currRow][currCol];
	Tile destTile = tiles[destRow][destCol];

	currTile.pieceOnTile = null;
	currTile.hasPiece = false;
	if (destTile.hasPiece) {
	    // remove from 'bag' of pieces left on board
	    if (destTile.pieceOnTile.color == Piece.BLACK)
		blackPieces.remove(destTile.pieceOnTile);
	    else
		whitePieces.remove(destTile.pieceOnTile);
	}
	if (temp instanceof King) {
	    updateKingPos(temp.color, destRow, destCol);
	}
	temp.rowPos = destRow;
	temp.colPos = destCol;
	destTile.pieceOnTile = temp;
	destTile.hasPiece = true;
    }

    /**
     * updates the global kings position
     * 
     * @param color
     *            color of king being updated
     * @param row
     *            new row pos of the king
     * @param col
     *            new col pos of the king
     */
    public void updateKingPos(int color, int row, int col) {
	if (color == Piece.WHITE) {
	    whiteKingRowPos = row;
	    whiteKingColPos = col;
	} else {
	    blackKingRowPos = row;
	    blackKingColPos = col;
	}
    }

    /**
     * does all the bookkeeping to put a piece on the board
     * 
     */
    public void placePiece(Piece p) {
	int row = p.rowPos;
	int col = p.colPos;
	if (p instanceof King)
	    updateKingPos(p.color, row, col);
	tiles[row][col].placePiece(p);
	if (p.color == Piece.BLACK)
	    blackPieces.add(p);
	else
	    whitePieces.add(p);
    }

    /**
     * undoes a move
     */
    public void undo() {
	if (lastmove == null) {
	    return;
	}
	lastmove.undo(this);
	lastmove = null;
    }
}
