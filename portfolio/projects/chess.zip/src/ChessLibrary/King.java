package ChessLibrary;

public class King extends Piece {

    public King(int color, int row, int col) {
	super(color, row, col);
	// TODO Auto-generated constructor stub
    }

    /**
     * A king can move to nearest neighbors
     */
    @Override
    public boolean validMove(Board board, int row, int col) {
	return (Math.abs(row - rowPos) == 1 || Math.abs(row - rowPos) == 0)
		&& ((Math.abs(col - colPos) == 1 || Math.abs(col - colPos) == 0))
		&& super.emptyOrEnemy(board, row, col);
    }
}
