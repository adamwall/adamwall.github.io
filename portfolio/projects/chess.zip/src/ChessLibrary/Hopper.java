package ChessLibrary;

/**
 * 
 * @file Hopper.java
 * @author agwall2
 * @date Feb 19, 2015
 * 
 */
public class Hopper extends Piece {

    public Hopper(int color, int row, int col) {
	super(color, row, col);
	// TODO Auto-generated constructor stub
    }

    /**
     * A hopper can hop over any unit if they are nearest neighbor
     */
    @Override
    public boolean validMove(Board board, int row, int col) {
	if (row == rowPos - 2) {
	    // up
	    if (col == colPos && board.tiles[rowPos - 1][colPos].hasPiece
		    && super.emptyOrEnemy(board, row, col))
		return true;
	    // upleft
	    if (col == colPos - 2
		    && board.tiles[rowPos - 1][colPos - 1].hasPiece
		    && super.emptyOrEnemy(board, row, col))
		return true;
	    // upright
	    if (col == colPos + 2
		    && board.tiles[rowPos - 1][colPos + 1].hasPiece
		    && super.emptyOrEnemy(board, row, col))
		return true;
	}
	if (row == rowPos + 2) {
	    // down
	    if (col == colPos && board.tiles[rowPos + 1][colPos].hasPiece
		    && super.emptyOrEnemy(board, row, col))
		return true;
	    // downleft
	    if (col == colPos - 2
		    && board.tiles[rowPos + 1][colPos - 1].hasPiece
		    && super.emptyOrEnemy(board, row, col))
		return true;
	    // downright
	    if (col == colPos + 2
		    && board.tiles[rowPos + 1][colPos + 1].hasPiece
		    && super.emptyOrEnemy(board, row, col))
		return true;
	}
	if (row == rowPos) {
	    // left
	    if (col == colPos - 2 && board.tiles[rowPos][colPos - 1].hasPiece
		    && super.emptyOrEnemy(board, row, col))
		return true;
	    // right
	    if (col == colPos + 2 && board.tiles[rowPos][colPos + 1].hasPiece
		    && super.emptyOrEnemy(board, row, col))
		return true;
	}
	return false;
    }

}
