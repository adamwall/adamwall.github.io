package ChessLibrary;

public class Game {

    public Game() {
	// TODO Auto-generated constructor stub
    }

    /**
     * tests whether a certain color is in check
     * 
     * @param board
     *            the board being played on
     * @param colorUnderAttack
     *            the color being under attack
     * @param row
     *            the row position of the king under attack
     * @param col
     *            the col position of the king under attack
     * @return
     */
    public boolean isInCheck(Board board, int colorUnderAttack, int row, int col) {
	// iterate over all the opposing pieces to see if it can be attacked at
	// that position
	if (colorUnderAttack == Piece.BLACK) {
	    for (Piece p : board.whitePieces) {
		if (p.validMove(board, row, col))
		    return true;
	    }
	    return false;
	}
	if (colorUnderAttack == Piece.WHITE) {
	    for (Piece p : board.blackPieces) {
		if (p.validMove(board, row, col))
		    return true;
	    }
	    return false;
	}
	return false;
    }

    /**
     * tests whether a certain color is in checkmate
     * 
     * @param board
     *            board being played on
     * @param colorUnderAttack
     *            the color that is under attack
     * @return
     */
    public boolean isInCheckMate(Board board, int colorUnderAttack) {
	LastMove moveBefore = board.lastmove;
	// check all possible legal moves, if no move can bring king out of
	// check, then checkmate.
	if (colorUnderAttack == Piece.BLACK) {
	    for (Piece p : board.blackPieces) {
		for (int row = 0; row < board.rows; row++) {
		    for (int col = 0; col < board.columns; col++) {
			// check all possible moves to see if any is legal
			if (p.move(board, row, col) == 0) {
			    board.undo();
			    board.lastmove = moveBefore;
			    return false;
			}
		    }
		}
	    }
	}
	if (colorUnderAttack == Piece.WHITE) {
	    for (Piece p : board.whitePieces) {
		for (int row = 0; row < board.rows; row++) {
		    for (int col = 0; col < board.columns; col++) {
			if (p.move(board, row, col) == 0) {
			    board.undo();
			    board.lastmove = moveBefore;
			    return false;
			}
		    }
		}
	    }
	}
	return true;
    }
}
