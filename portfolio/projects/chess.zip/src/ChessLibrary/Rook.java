package ChessLibrary;

/**
 * 
 * @file Rook.java
 * @author agwall2
 * @date Feb 10, 2015
 * 
 */
public class Rook extends Piece {

    public Rook(int color, int row, int col) {
	super(color, row, col);
	// TODO Auto-generated constructor stub
    }

    /**
     * a rook can move up and down, or left and right
     */
    @Override
    public boolean validMove(Board board, int row, int col) {
	// same row
	if (rowPos == row) {
	    // check for interference in path
	    if (col > colPos) {
		// moving right
		for (int path = colPos + 1; path < col; path++) {
		    if (board.tiles[row][path].hasPiece)
			return false;
		}
	    } else if (col < colPos) {
		// moving left
		for (int path = colPos - 1; path > col; path--) {
		    if (board.tiles[row][path].hasPiece)
			return false;
		}
	    }
	    if (super.emptyOrEnemy(board, row, col))
		return true;
	}
	// same col
	if (colPos == col) {
	    // check for interference in path
	    if (row > rowPos) {
		// moving down
		for (int path = rowPos + 1; path < row; path++) {
		    if (board.tiles[path][col].hasPiece)
			return false;
		}
	    } else if (row < rowPos) {
		// moving up
		for (int path = rowPos - 1; path > row; path--) {
		    if (board.tiles[path][col].hasPiece)
			return false;
		}
	    }
	    if (super.emptyOrEnemy(board, row, col))
		return true;
	}
	return false;
    }

}
