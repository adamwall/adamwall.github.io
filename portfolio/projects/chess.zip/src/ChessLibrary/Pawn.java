package ChessLibrary;

/**
 * 
 * @file Pawn.java
 * @author agwall2
 * @date Feb 10, 2015
 * 
 */
public class Pawn extends Piece {

    public Pawn(int color, int x, int y) {
	super(color, x, y);
	// TODO Auto-generated constructor stub
    }

    /**
     * a pawn has three different move types (1) moving up or down 1 space,
     * depending on color (2) moving up or down 2 spaces from the starting
     * position (3) moving diagonally to take a piece
     */
    @Override
    public boolean validMove(Board board, int row, int col) {
	if (color == Piece.WHITE)
	    return validMoveWhite(board, row, col);
	else if (color == Piece.BLACK)
	    return validMoveBlack(board, row, col);
	else
	    return false;
    }

    public boolean validMoveWhite(Board board, int row, int col) {
	// 2 moves up from start
	if (rowPos == board.rows - 2 && row == rowPos - 2 && colPos == col
		&& !board.tiles[row][col].hasPiece
		&& !board.tiles[rowPos - 1][colPos].hasPiece)
	    return true;
	// 1 move up
	if (row == rowPos - 1 && colPos == col) {
	    // check if piece exists there
	    if (board.tiles[row][col].hasPiece)
		return false;
	    else
		return true;
	}
	// diagonal if opposing piece
	if (row == rowPos - 1 && (col == colPos + 1 || col == colPos - 1)) {
	    if (board.tiles[row][col].hasPiece || row == board.blackKingRowPos
		    && col == board.blackKingColPos) {
		if (row == board.blackKingRowPos
			&& col == board.blackKingColPos)
		    return true;
		if (board.tiles[row][col].pieceOnTile.color == Piece.BLACK)
		    return true;
	    } else
		return false;
	}
	return false;
    }

    public boolean validMoveBlack(Board board, int row, int col) {
	// 2 moves down from start
	if (rowPos == 1 && row == rowPos + 2 && colPos == col
		&& !board.tiles[row][col].hasPiece
		&& !board.tiles[rowPos + 1][colPos].hasPiece)
	    return true;
	// 1 move down
	if (row == rowPos + 1 && colPos == col) {
	    // check if piece exists there
	    if (board.tiles[row][col].hasPiece)
		return false;
	    else
		return true;
	}
	// diagonal if opposing piece
	if (row == rowPos + 1 && (col == colPos + 1 || col == colPos - 1)) {
	    if (board.tiles[row][col].hasPiece || row == board.whiteKingRowPos
		    && col == board.whiteKingColPos) {
		if (row == board.whiteKingRowPos
			&& col == board.whiteKingColPos)
		    return true;
		if (board.tiles[row][col].pieceOnTile.color == Piece.WHITE)
		    return true;
	    } else
		return false;
	}
	return false;
    }
}
