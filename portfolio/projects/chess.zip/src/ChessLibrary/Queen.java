package ChessLibrary;

/**
 * 
 * @file Queen.java
 * @author agwall2
 * @date Feb 11, 2015
 * 
 */
public class Queen extends Piece {

    public Queen(int color, int row, int col) {
	super(color, row, col);
	// TODO Auto-generated constructor stub
    }

    /**
     * A Queen can move left, right, up, down, and diagonally
     */
    @Override
    public boolean validMove(Board board, int row, int col) {
	if (validMoveVerticalHorizontal(board, row, col))
	    return true;
	if (validMoveDiagonal(board, row, col))
	    return true;
	return false;
    }

    public boolean validMoveVerticalHorizontal(Board board, int row, int col) {
	// same row
	if (rowPos == row) {
	    // check for interference in path
	    if (col > colPos) {
		// moving right
		for (int path = colPos + 1; path < col; path++) {
		    if (board.tiles[row][path].hasPiece)
			return false;
		}
	    } else if (col < colPos) {
		// moving left
		for (int path = colPos - 1; path > col; path--) {
		    if (board.tiles[row][path].hasPiece)
			return false;
		}
	    }
	    if (super.emptyOrEnemy(board, row, col))
		return true;
	}
	// same col
	if (colPos == col) {
	    // check for interference in path
	    if (row > rowPos) {
		// moving down
		for (int path = rowPos + 1; path < row; path++) {
		    if (board.tiles[path][col].hasPiece)
			return false;
		}
	    } else if (row < rowPos) {
		// moving up
		for (int path = rowPos - 1; path > row; path--) {
		    if (board.tiles[path][col].hasPiece)
			return false;
		}
	    }
	    if (super.emptyOrEnemy(board, row, col))
		return true;
	}
	return false;
    }

    public boolean validMoveDiagonal(Board board, int row, int col) {
	// diagonally upleft
	// diagonally upright
	if (rowPos > row && Math.abs(rowPos - row) == Math.abs(col - colPos)) {
	    if (colPos > col) {
		// diag left
		for (int pathAdd = 1; pathAdd < rowPos - row; pathAdd++) {
		    if (board.tiles[rowPos - pathAdd][colPos - pathAdd].hasPiece)
			return false;
		}
	    } else if (colPos < col) {
		// diag right
		for (int pathAdd = 1; pathAdd < rowPos - row; pathAdd++) {
		    if (board.tiles[rowPos - pathAdd][colPos + pathAdd].hasPiece)
			return false;
		}
	    }
	    if (super.emptyOrEnemy(board, row, col))
		return true;
	}
	// diagonally downleft
	// diagonally downright
	if (rowPos < row && Math.abs(rowPos - row) == Math.abs(col - colPos)) {
	    if (colPos > col) {
		// diag left
		for (int pathAdd = 1; pathAdd < row - rowPos; pathAdd++) {
		    if (board.tiles[rowPos + pathAdd][colPos - pathAdd].hasPiece)
			return false;
		}
	    } else if (colPos < col) {
		// diag right
		for (int pathAdd = 1; pathAdd < row - rowPos; pathAdd++) {
		    if (board.tiles[rowPos + pathAdd][colPos + pathAdd].hasPiece)
			return false;
		}
	    }
	    if (super.emptyOrEnemy(board, row, col))
		return true;
	}
	return false;
    }
}
