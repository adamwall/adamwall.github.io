package ChessLibrary;

/**
 * 
 * @file Piece.java
 * @author agwall2
 * @date Feb 10, 2015
 * 
 */

/**
 * abstract class to hold pieces
 * 
 * @author user
 *
 *
 */
public class Piece {
    public static final int BLACK = 0;
    public static final int WHITE = 1;

    public int rowPos;
    public int colPos;
    public int color;

    /**
     * Constructor mostly used when placing the pieces at the start of the game
     * 
     * @param color
     * @param positionOnBoard
     */
    public Piece(int color, int row, int col) {
	this.color = color;
	this.rowPos = row;
	this.colPos = col;
    }

    /**
     * Moves the piece to a new position on the board
     * 
     * 
     * @param board
     *            the board that the piece is on
     * @param row
     *            the row of the new position
     * @param col
     *            the column of the new position
     * @return 0 if successful move, -1 if unsuccessful
     */
    public int move(Board board, int row, int col) {
	// check for existing piece on new pos
	if (!emptyOrEnemy(board, row, col))
	    return -1;
	// check if valid move for piece's type
	if (!validMove(board, row, col))
	    return -1;
	// check if move will cause check to own king
	if (!tryMove(board, row, col))
	    return -1;
	return 0;
    }

    /**
     * attempts the given move and then tests if the move would cause a check
     * for its own color
     * 
     * @param board
     *            board being played on
     * @param row
     *            row position the piece would like to move
     * @param col
     *            col position the piece would like to move
     * @return true if the move was successful, false if not
     */
    public boolean tryMove(Board board, int row, int col) {
	Tile destTile = board.tiles[row][col];
	LastMove move = new LastMove(this, true, rowPos, colPos,
		destTile.pieceOnTile, destTile.hasPiece, row, col);
	board.lastmove = move;
	Game g = new Game();
	board.movePiece(rowPos, colPos, row, col);
	if (this.color == Piece.BLACK) {
	    if (g.isInCheck(board, this.color, board.blackKingRowPos,
		    board.blackKingColPos)) {
		// if the move causes check for the king, revert everything and
		// return
		move.undo(board);
		return false;
	    }
	} else {
	    if (g.isInCheck(board, this.color, board.whiteKingRowPos,
		    board.whiteKingColPos)) {
		move.undo(board);
		return false;
	    }
	}
	return true;
    }

    /**
     * Checks if this piece's movement is possible for this type of piece
     * 
     * @param row
     *            the row position of the new move
     * @param col
     *            the column position of the new move
     * @return
     */
    public boolean validMove(Board board, int row, int col) {
	return false;
    }

    /**
     * converts the pieces position to chess positions
     * 
     * @return
     */
    public String positionToString() {
	char xToString = (char) ('a' + rowPos);
	int yToString = ((colPos + 1) + 8) % 8; // offset by 1, then add 8 and
						// mod 8 because the top row is
						// 8 and bottom row is 1
	String positionAsString = "" + xToString + Integer.toString(yToString);
	return positionAsString;
    }

    /**
     * used in the valid move function, checks the state of the endpoint of a
     * pieces move
     * 
     * @param board
     * @param row
     * @param col
     * @return true if the tile is empty or contains and enemy, false otherwise
     */
    public boolean emptyOrEnemy(Board board, int row, int col) {
	if (board.tiles[row][col].hasPiece) {
	    // check if ally or enemy
	    if (board.tiles[row][col].pieceOnTile.color == this.color)
		return false;
	    else
		return true;
	} else
	    return true;
    }
}
