package ChessLibrary;

/**
 * 
 * Tiles of the Board in the Chess game.
 * 
 * 
 * @file Tile.java
 * @author agwall2
 * @date Feb 10, 2015
 *
 */
public class Tile {

    public static final int DARK = 0;
    public static final int LIGHT = 1;

    public int color;
    public boolean hasPiece;
    public Piece pieceOnTile;

    /**
     * Constructor for tile with no piece on it
     * 
     * @param color
     */
    public Tile(int color) {
	this.color = color;
	this.hasPiece = false;
	this.pieceOnTile = null;
    }

    /**
     * constructor for tile with a piece on it
     * 
     * @param color
     * @param piece
     */
    public Tile(int color, Piece piece) {
	this.color = color;
	this.pieceOnTile = piece;
	this.hasPiece = true;
    }

    /**
     * places a piece on the tile
     * 
     * @param piece
     */
    public void placePiece(Piece piece) {
	this.pieceOnTile = piece;
	this.hasPiece = true;
    }
}
