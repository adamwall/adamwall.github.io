package ChessLibrary;

/**
 * 
 * @file Swapper.java
 * @author agwall2
 * @date Feb 19, 2015
 * 
 */
public class Swapper extends Piece {

    public Swapper(int color, int row, int col) {
	super(color, row, col);
	// TODO Auto-generated constructor stub
    }

    /**
     * Swapper can swap with ally units
     */
    @Override
    public boolean validMove(Board board, int row, int col) {
	if (board.getPiece(row, col) == null)
	    return false;
	if (row == rowPos && col == colPos)
	    return false;
	return ((board.getPiece(row, col).color == this.color) && !(board
		.getPiece(row, col) instanceof Bishop));
    }

    /**
     * A swapper can only move by swapping its position with other ally pieces.
     * A swapper cannot swap places with a bishop
     */
    @Override
    public int move(Board board, int row, int col) {
	if (!validMove(board, row, col))
	    return -1;
	if (!tryMove(board, row, col))
	    return -1;
	return 0;
    }

    /**
     * attempts the move and tests if it would cause a check
     */
    @Override
    public boolean tryMove(Board board, int row, int col) {
	Tile thisTile = board.tiles[rowPos][colPos];
	Tile destTile = board.tiles[row][col];
	Game g = new Game();
	LastMove move = new LastMove(this, true, rowPos, colPos,
		destTile.pieceOnTile, destTile.hasPiece, row, col);
	board.lastmove = move;

	int tempRow = rowPos;
	int tempCol = colPos;
	Piece destPiece = destTile.pieceOnTile;
	boolean destHasPiece = destTile.hasPiece;

	this.rowPos = row;
	this.colPos = col;
	destTile.pieceOnTile = this;

	destPiece.rowPos = tempRow;
	destPiece.colPos = tempCol;
	thisTile.pieceOnTile = destPiece;

	if (destPiece instanceof King) {
	    board.updateKingPos(destPiece.color, tempRow, tempCol);
	}
	if (this.color == Piece.BLACK) {
	    if (g.isInCheck(board, this.color, board.blackKingRowPos,
		    board.blackKingColPos)) {
		// if the move causes check for the king, revert everything and
		// return
		move.undo(board);
		return false;
	    }
	} else {
	    if (g.isInCheck(board, this.color, board.whiteKingRowPos,
		    board.whiteKingColPos)) {
		// if the move causes check for the king, revert everything and
		// return
		move.undo(board);
		return false;
	    }
	}
	return true;
    }
}
