package ChessLibrary;

/**
 * 
 * @file Knight.java
 * @author agwall2
 * @date Feb 11, 2015
 * 
 */
public class Knight extends Piece {

    public Knight(int color, int row, int col) {
	super(color, row, col);
	// TODO Auto-generated constructor stub
    }

    /**
     * A knight can move in an L shape, two squares vertically and one square
     * horizontally, or two squares horizontally and one square vertically.
     */
    @Override
    public boolean validMove(Board board, int row, int col) {
	return ((Math.abs(row - rowPos) == 2 && Math.abs(col - colPos) == 1) || (Math
		.abs(row - rowPos) == 1 && Math.abs(col - colPos) == 2))
		&& super.emptyOrEnemy(board, row, col);
    }
}
